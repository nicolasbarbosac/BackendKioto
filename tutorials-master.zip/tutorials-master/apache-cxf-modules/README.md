## Apache CXF

This module contains articles about Apache CXF

## Relevant Articles:

- [Introduction to Apache CXF Aegis Data Binding](https://www.baeldung.com/aegis-data-binding-in-apache-cxf)
