## Apache Kafka

This module contains articles about Apache Kafka.

##### Building the project
You can build the project from the command line using: *mvn clean install*, or in an IDE.

### Relevant Articles:
- [Guide to Check if Apache Kafka Server Is Running](https://www.baeldung.com/apache-kafka-check-server-is-running)
