package com.baeldung.antlr.log.model;

public enum LogLevel {
    DEBUG, INFO, ERROR
}
