package com.example.socketserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocketserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
